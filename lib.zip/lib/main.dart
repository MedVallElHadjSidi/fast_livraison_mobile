import 'package:fast_livraison_mobile/HomePage.dart';
import 'package:fast_livraison_mobile/auth/login.dart';
import 'package:fast_livraison_mobile/auth/loginPhone.dart';
import 'package:fast_livraison_mobile/auth/signup.dart';
import 'package:fast_livraison_mobile/categories/addCategorie.dart';
import 'package:fast_livraison_mobile/filterFireStore.dart';
import 'package:fast_livraison_mobile/geolocations/Mygeo.dart';
import 'package:firebase_auth/firebase_auth.dart';
// import 'package:fast_livraison_mobile/geolocations/Mygeo.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';
import 'services/auth_service.dart';
import 'package:fast_livraison_mobile/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await GoogleSignIn.instance.initialize(
    serverClientId:
        "1028398623935-1il9pgsk4hituur6tejmth87ase5p47d.apps.googleusercontent.com",
  );
  runApp(
    // ✅ Provider ici, AVANT tout le reste
    ChangeNotifierProvider(create: (_) => AuthService(), child: const MyApp()),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // This widget is the root of your application.

  @override
  void initState() {
    // TODO: implement initState
    FirebaseAuth.instance.authStateChanges().listen((User? user) {
      if (user == null) {
        print('User is currently signed out!');
      } else {
        print('User is signed in!');
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          iconTheme: IconThemeData(color: Colors.orange),
          backgroundColor: Colors.grey[50],
          titleTextStyle: TextStyle(
            color: Colors.orange,
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      // home: (FirebaseAuth.instance.currentUser !=null    ) ? Homepage(): LoginPhone(),
      home: Consumer<AuthService>(
        builder: (context, authService, _) {
          if (authService.isLoggedIn) {
            return const FilterFireStore();
          }
          return const LoginPhone();
        },
      ),
      routes: {
        "singup": (context) => Signup(),
        "home": (context) => Homepage(),
        "login": (context) => login(),
        "login-phone": (context) => LoginPhone(),
        "add-categorie": (context) => AddCategorie(),
        // "geo": (context) => Mygeo(),
      },
    );
  }
}
