import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class FilterFireStore extends StatefulWidget {
  const FilterFireStore({super.key});

  @override
  State<FilterFireStore> createState() => _FilterFireStoreState();
}

class _FilterFireStoreState extends State<FilterFireStore> {
  bool isLoading=true;
  List<QueryDocumentSnapshot> users=[];

  getDataUsers() async{

  QuerySnapshot querySnapshot=  await FirebaseFirestore.instance.collection("users").orderBy("age").get();
     isLoading=false;
  users.addAll(querySnapshot.docs);


  setState(() {
   
  });

  }

  @override
  void initState() {
    // TODO: implement initState
    getDataUsers();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Filter FireStore"),
      ),
      body: isLoading? Center(child: CircularProgressIndicator(),) : Container(
        // padding: EdgeInsets.all(10),
        child: ListView.builder(
          itemCount: users.length,
          itemBuilder: (context, index){
            return Card(
              child: ListTile(

                title: Text(users[index]['username']),
                subtitle: Text(users[index]['age'].toString()),
                trailing: Text(users[index]['money'].toString()),
              ),
            );
          },
        ),
      ),
    );
  }
}